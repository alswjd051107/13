module Member {
    requires java.desktop; 
    requires java.sql;    
}