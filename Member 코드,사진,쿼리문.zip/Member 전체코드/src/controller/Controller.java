package controller;

import java.sql.*;
import java.util.ArrayList;
import model.Model;

public class Controller {

    final String driver = "org.mariadb.jdbc.Driver";
    final String DB_IP = "localhost";
    final String DB_PORT = "3306";
    final String DB_NAME = "test";
    final String DB_URL = "jdbc:mariadb://" + DB_IP + ":" + DB_PORT + "/" + DB_NAME;

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    Statement st = null;

    public Controller() {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(DB_URL, "root", "1234");
            if (conn != null) {
                System.out.println("DB 접속 성공");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("드라이버 로드 실패");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("DB 접속 실패");
            e.printStackTrace();
        }
    }

    public boolean login(String id, String password) {
        try {
            st = conn.createStatement();
            rs = st.executeQuery("SELECT * FROM member WHERE id = '" + id + "' AND password = '" + password + "';");
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isAdmin(String id) {
        return id.equals("admin");
    }

    public void insertMember(Model model) {
        try {
            st = conn.createStatement();
            st.executeUpdate(
                "INSERT INTO member (id, password, name, birth, tel) VALUES ('" + 
                model.getId() + "', '" + model.getPassword() + "', '" + 
                model.getName() + "', '" + model.getBirth() + "', '" + model.getTel() + "');"
            );
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList<Model> readMember() {
        ArrayList<Model> arr = new ArrayList<>();
        try {
            st = conn.createStatement();
            rs = st.executeQuery("SELECT * FROM member;");
            while (rs.next()) {
                arr.add(new Model(rs.getString("id"), rs.getString("password"), 
                                  rs.getString("name"), rs.getString("birth"), rs.getString("tel")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return arr;
    }

    public ArrayList<Model> readUserData(String id) {
        ArrayList<Model> arr = new ArrayList<>();
        try {
            st = conn.createStatement();
            rs = st.executeQuery("SELECT * FROM member WHERE id = '" + id + "';");
            while (rs.next()) {
                arr.add(new Model(rs.getString("id"), rs.getString("password"), 
                                  rs.getString("name"), rs.getString("birth"), rs.getString("tel")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return arr;
    }

    public void updateMember(String id, String tel) {
        try {
            st = conn.createStatement();
            st.executeUpdate("UPDATE member SET tel = '" + tel + "' WHERE id = '" + id + "';");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteMember(String id) {
        try {
            st = conn.createStatement();
            st.executeUpdate("DELETE FROM member WHERE id = '" + id + "';");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList<Model> searchMember(String content) {
        ArrayList<Model> arr = new ArrayList<>();
        try {
            st = conn.createStatement();
            rs = st.executeQuery("SELECT * FROM member WHERE name LIKE '%" + content + "%';");
            while (rs.next()) {
                arr.add(new Model(rs.getString("id"), rs.getString("password"), 
                                  rs.getString("name"), rs.getString("birth"), rs.getString("tel")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return arr;
    }
}