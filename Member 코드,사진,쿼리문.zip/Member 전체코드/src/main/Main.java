package main;

import view.LoginForm;

public class Main {
    public static void main(String[] args) {
        new LoginForm();
    }
}