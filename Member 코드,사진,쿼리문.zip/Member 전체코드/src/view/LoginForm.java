package view;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import controller.Controller;

public class LoginForm {
    JFrame frame = new JFrame("로그인");
    JPanel panel = new JPanel();
    JTextField idField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JLabel idLabel = new JLabel("아이디: ");
    JLabel passwordLabel = new JLabel("비밀번호: ");
    JButton loginButton = new JButton("로그인");
    JButton registerButton = new JButton("회원가입");

    public LoginForm() {
        GUI_init();
    }

    public void GUI_init() {
        frame.setBounds(50, 50, 300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        panel.setLayout(null);
        frame.add(panel);

        idLabel.setBounds(20, 20, 80, 30);
        panel.add(idLabel);
        idField.setBounds(100, 20, 160, 30);
        panel.add(idField);

        passwordLabel.setBounds(20, 60, 80, 30);
        panel.add(passwordLabel);
        passwordField.setBounds(100, 60, 160, 30);
        panel.add(passwordField);

        loginButton.setBounds(20, 100, 100, 30);
        panel.add(loginButton);
        registerButton.setBounds(140, 100, 100, 30);
        panel.add(registerButton);

        Controller controller = new Controller();

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();
                if (controller.login(id, password)) {
                    frame.dispose();
                    if (controller.isAdmin(id)) {
                        new View();
                    } else {
                        new UserView(id);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "로그인 실패: 아이디 또는 비밀번호가 잘못되었습니다.");
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RegisterForm();
            }
        });
    }
}