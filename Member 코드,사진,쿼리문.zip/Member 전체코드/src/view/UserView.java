package view;

import javax.swing.*;
import java.util.ArrayList;
import controller.Controller;
import model.Model;

public class UserView {
    JFrame frame = new JFrame("내 정보");
    JPanel panel = new JPanel();
    JTextArea textArea = new JTextArea();

    public UserView(String id) {
        GUI_init(id);
    }

    public void GUI_init(String id) {
        frame.setBounds(50, 50, 400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        panel.setLayout(null);
        frame.add(panel);

        JScrollPane jsp = new JScrollPane(textArea);
        jsp.setBounds(20, 20, 350, 230);
        panel.add(jsp);

        Controller controller = new Controller();
        ArrayList<Model> arr = controller.readUserData(id);

        textArea.append("\t아이디\t이름\t생년월일\t전화번호\n");
        textArea.append("\t------------------------------------------------------------\n");

        for (Model model : arr) {
            textArea.append("\t" + model.getId() + "\t" + model.getName() + "\t" + 
                            model.getBirth() + "\t" + model.getTel() + "\n");
        }
    }
}