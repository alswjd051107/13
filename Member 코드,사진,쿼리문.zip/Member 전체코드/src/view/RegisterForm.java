package view;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import controller.Controller;
import model.Model;

public class RegisterForm {
    JFrame frame = new JFrame("회원가입");
    JPanel panel = new JPanel();
    JTextField idField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JTextField nameField = new JTextField();
    JTextField birthField = new JTextField();
    JTextField telField = new JTextField();
    JLabel idLabel = new JLabel("아이디: ");
    JLabel passwordLabel = new JLabel("비밀번호: ");
    JLabel nameLabel = new JLabel("이름: ");
    JLabel birthLabel = new JLabel("생년월일: ");
    JLabel telLabel = new JLabel("전화번호: ");
    JButton registerButton = new JButton("가입");

    public RegisterForm() {
        GUI_init();
    }

    public void GUI_init() {
        frame.setBounds(50, 50, 300, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
        panel.setLayout(null);
        frame.add(panel);

        idLabel.setBounds(20, 20, 80, 30);
        panel.add(idLabel);
        idField.setBounds(100, 20, 160, 30);
        panel.add(idField);

        passwordLabel.setBounds(20, 60, 80, 30);
        panel.add(passwordLabel);
        passwordField.setBounds(100, 60, 160, 30);
        panel.add(passwordField);

        nameLabel.setBounds(20, 100, 80, 30);
        panel.add(nameLabel);
        nameField.setBounds(100, 100, 160, 30);
        panel.add(nameField);

        birthLabel.setBounds(20, 140, 80, 30);
        panel.add(birthLabel);
        birthField.setBounds(100, 140, 160, 30);
        panel.add(birthField);

        telLabel.setBounds(20, 180, 80, 30);
        panel.add(telLabel);
        telField.setBounds(100, 180, 160, 30);
        panel.add(telField);

        registerButton.setBounds(100, 220, 100, 30);
        panel.add(registerButton);

        Controller controller = new Controller();

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();
                String name = nameField.getText().trim();
                String birth = birthField.getText().trim();
                String tel = telField.getText().trim();

                if (!id.isBlank() && !password.isBlank() && !name.isBlank() && !birth.isBlank() && !tel.isBlank()) {
                    controller.insertMember(new Model(id, password, name, birth, tel));
                    JOptionPane.showMessageDialog(frame, "회원가입 완료!");
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(frame, "모든 필드를 입력하세요.");
                }
            }
        });
    }
}