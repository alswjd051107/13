CREATE TABLE `member` (
    `id` VARCHAR(50) NOT NULL,
    `password` VARCHAR(50) NOT NULL,
    `name` VARCHAR(50) NOT NULL,
    `birth` VARCHAR(10) NOT NULL,
    `tel` VARCHAR(20) NOT NULL,
    PRIMARY KEY (`id`)
);